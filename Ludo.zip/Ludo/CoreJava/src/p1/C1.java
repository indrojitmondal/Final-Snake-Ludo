package p1;

public class C1 {
    
    public static void cal(int v)
     {
    	 System.out.println(v);
     }
     public C1()
     {
    	 
     }
    
      public static void main(String[] arg)
      {
    	 C1.cal(20);
      }
}
